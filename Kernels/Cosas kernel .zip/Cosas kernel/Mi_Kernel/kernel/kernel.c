// kernel/kernel.c
__attribute__((section(".multiboot")))
const unsigned int header[] = {
    0x1BADB002,       // Magic
    0x00,             // Flags
    -(0x1BADB002)     // Checksum
};
// kernel/kernel.c
void kernel_main() {
    char *video = (char*) 0xb8000;
    const char *msg = "Hola desde mi kernel con GRUB!";

    for (int i = 0; msg[i] != '\0'; i++) {
        video[i * 2] = msg[i];
        video[i * 2 + 1] = 0x07;
    }

    while (1) {}
}

