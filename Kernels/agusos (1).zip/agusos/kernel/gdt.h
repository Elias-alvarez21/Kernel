#pragma once

void init_gdt();
