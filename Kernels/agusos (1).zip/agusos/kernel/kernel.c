#include "screen.h"
#include "idt.h"
#include "irq.h"
#include "keyboard.h"
#include "io.h"
#include "gdt.h"
#include "shell.h"

#define OS_NAME "Agus OS"
#define OS_VERSION "v1.0"

extern void irq1(); // desde irq.asm

__attribute__((section(".multiboot")))
const unsigned int multiboot_header[] = {
    0x1BADB002, 0x0, -(0x1BADB002)
};

void kernel_main() {
    init_gdt();
    clear_screen();
    print(OS_NAME " " OS_VERSION "\n");
    print("Inicializando...\n");

    remap_pic();

    outb(0x21, 0xFD);

    install_idt();
    set_idt_gate(33, (unsigned int)irq1); // IRQ1 = vector 33
    enable_interrupts();

    print("Listo! Escribi algo:\n");
    shell_start();


    while (1) {}
}
