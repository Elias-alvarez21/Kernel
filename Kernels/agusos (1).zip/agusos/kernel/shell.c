#include "shell.h"
#include "screen.h"
#include "keyboard.h"
#include <stdbool.h>
#include "string.h"

#define MAX_BUFFER 128

static char input_buffer[MAX_BUFFER];
static int buffer_pos = 0;

void parse_command(const char* input, char* cmd, char* args) {
    int i = 0;
    while (input[i] && input[i] != ' ') {
        cmd[i] = input[i];
        i++;
    }
    cmd[i] = '\0';

    // Saltar espacios
    while (input[i] == ' ') i++;

    int j = 0;
    while (input[i]) {
        args[j++] = input[i++];
    }
    args[j] = '\0';
}


void handle_command(const char* input) {
    char cmd[32];
    char args[96];

    parse_command(input, cmd, args);

    if (strcmp(cmd, "clear") == 0) {
        clear_screen();
    } else if (strcmp(cmd, "help") == 0) {
        print("Comandos disponibles:\n - help\n - clear\n - echo <msg>\n - saludar <nombre>\n");
    } else if (strcmp(cmd, "echo") == 0) {
        print(args);
        print("\n");
    } else if (strcmp(cmd, "saludar") == 0) {
        print("Hola ");
        print(args);
        print(", como estas? :)\n");
    } else if (strcmp(cmd, "duplicar") == 0) {
        print("Duplicando el numero: ");
        print(args);
        print("\n");
        print("Resultado: ");
        print("No voy a duplicar, me enoje");
        print("\n");
    }
    else if (strcmp(cmd, "saludar2") == 0) {
        print("Hola, este es saludar 2 :D ");
        print(args);
        print(", como estas? :)\n");
    }
    else {
        print("Comando no reconocido, usa 'help' para ver los comandos disponibles\n");
    }
}


void shell_handle_char(char c) {
    if (c == '\n') {
        input_buffer[buffer_pos] = '\0';
        print("\n");

        handle_command(input_buffer);
        buffer_pos = 0;
        input_buffer[0] = '\0';
        print("> ");
        return;
    }

    if (c == '\b' || c == 127) {
    if (buffer_pos > 0) {
        buffer_pos--;
        input_buffer[buffer_pos] = '\0';

        // Simula borrar en pantalla
        delete_last_char();
    }
    return;
}


    if (buffer_pos < MAX_BUFFER - 1) {
        input_buffer[buffer_pos++] = c;
        input_buffer[buffer_pos] = '\0';
        print_char(c);
    }
}

void shell_start() {
    buffer_pos = 0;
    input_buffer[0] = '\0';
    print("> ");
}
