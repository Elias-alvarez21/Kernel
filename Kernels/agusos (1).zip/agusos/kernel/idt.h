#pragma once

void install_idt();
void set_idt_gate(int n, unsigned int handler);
