#pragma once

void remap_pic();
void enable_interrupts();
