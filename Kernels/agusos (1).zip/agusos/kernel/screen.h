#pragma once

void print(const char* str);
void print_char(char c);
void scroll_if_needed();
void clear_screen();
void delete_last_char();

