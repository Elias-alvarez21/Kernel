#include <stdint.h>
#include "screen.h"

#define VGA_WIDTH 80
#define VGA_HEIGHT 25
#define VGA_MEMORY (char*)0xB8000

volatile char* video = VGA_MEMORY;
int cursor_row = 0;
int cursor_col = 0;

void scroll_if_needed() {
    if (cursor_row < VGA_HEIGHT) return;

    for (int row = 1; row < VGA_HEIGHT; row++) {
        for (int col = 0; col < VGA_WIDTH; col++) {
            int from = (row * VGA_WIDTH + col) * 2;
            int to = ((row - 1) * VGA_WIDTH + col) * 2;
            video[to] = video[from];
            video[to + 1] = video[from + 1];
        }
    }

    // Limpiar última línea
    for (int col = 0; col < VGA_WIDTH; col++) {
        int offset = ((VGA_HEIGHT - 1) * VGA_WIDTH + col) * 2;
        video[offset] = ' ';
        video[offset + 1] = 0x07;
    }

    cursor_row = VGA_HEIGHT - 1;
}

void delete_last_char() {
    if (cursor_col == 0 && cursor_row == 0) return;

    if (cursor_col == 0) {
        cursor_row--;
        cursor_col = 79;
    } else {
        cursor_col--;
    }

    int offset = (cursor_row * 80 + cursor_col) * 2;
    video[offset] = ' ';
    video[offset + 1] = 0x07;
}


void print_char(char c) {
    if (c == '\n') {
        cursor_row++;
        cursor_col = 0;
        scroll_if_needed();
        return;
    }

    int offset = (cursor_row * VGA_WIDTH + cursor_col) * 2;
    video[offset] = c;
    video[offset + 1] = 0x07;
    cursor_col++;

    if (cursor_col >= VGA_WIDTH) {
        cursor_col = 0;
        cursor_row++;
        scroll_if_needed();
    }
}

void print(const char* str) {
    while (*str) {
        print_char(*str++);
    }
}

void clear_screen() {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        video[i * 2] = ' ';
        video[i * 2 + 1] = 0x07;
    }
    cursor_row = 0;
    cursor_col = 0;
}
