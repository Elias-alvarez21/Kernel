#include <stdint.h>
#include "idt.h"

struct idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t zero;
    uint8_t type_attr;
    uint16_t offset_high;
} __attribute__((packed));

struct idt_ptr {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed));

extern void load_idt(uint32_t);  // Implementada en ASM

struct idt_entry idt[256];

void set_idt_gate(int n, unsigned int handler) {
    idt[n].offset_low = handler & 0xFFFF;
    idt[n].selector = 0x08; // Código segmento
    idt[n].zero = 0;
    idt[n].type_attr = 0x8E; // Presente, ring 0, tipo 32-bit interrupt gate
    idt[n].offset_high = (handler >> 16) & 0xFFFF;
}

void install_idt() {
    struct idt_ptr idt_reg;
    idt_reg.limit = sizeof(idt) - 1;
    idt_reg.base = (uint32_t)&idt;
    load_idt((uint32_t)&idt_reg);
}

